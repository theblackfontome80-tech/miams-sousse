/* =========================================================================
   MIAM'S — Interactions
   ========================================================================= */
(() => {
  "use strict";
  const R = window.MIAMS;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Chargement ---------- */
  const markLoaded = () => document.documentElement.classList.add("is-loaded");
  const heroImg = $(".hero__img img");
  if (heroImg && !heroImg.complete) {
    heroImg.addEventListener("load", markLoaded, { once: true });
    setTimeout(markLoaded, 1800); // garde-fou réseau lent
  } else {
    requestAnimationFrame(() => setTimeout(markLoaded, 250));
  }
  document.body.classList.add("js");

  /* ---------- Heure de Tunis ---------- */
  const tunisNow = () => {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Africa/Tunis", weekday: "short", hour: "2-digit", minute: "2-digit", hour12: false,
    }).formatToParts(new Date());
    const get = (t) => parts.find((p) => p.type === t)?.value;
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    return { day: days.indexOf(get("weekday")), minutes: (+get("hour") % 24) * 60 + +get("minute") };
  };
  const toMin = (hhmm) => { const [h, m] = hhmm.split(":").map(Number); return h * 60 + m; };

  const updateStatus = () => {
    const { minutes } = tunisNow();
    const open = minutes >= toMin(R.hours.open) && minutes < toMin(R.hours.close);
    $$("[data-status]").forEach((el) => {
      el.classList.toggle("is-open", open);
      el.classList.toggle("is-closed", !open);
      $("[data-status-text]", el).textContent = open ? "Ouvert · jusqu'à 23h" : "Fermé · ouvre à 11h";
    });
  };
  updateStatus();
  setInterval(updateStatus, 60_000);

  /* ---------- Horaires ---------- */
  const hoursEl = $("[data-hours]");
  if (hoursEl) {
    const names = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
    const today = tunisNow().day;
    hoursEl.innerHTML = names
      .map((n, i) => `<li class="${i === today ? "is-today" : ""}"><span>${n}</span><span>11:00 — 23:00</span></li>`)
      .join("");
  }

  /* ---------- Navigation ---------- */
  const nav = $(".nav");
  const dock = $(".dock");
  let lastY = scrollY;
  const onScroll = () => {
    const y = scrollY;
    nav.classList.toggle("is-solid", y > 30);
    nav.classList.toggle("is-hidden", y > 500 && y > lastY && !document.body.classList.contains("menu-open"));
    dock?.classList.toggle("is-visible", y > innerHeight * 0.6);
    lastY = y;
  };
  addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  // Lien actif selon la section visible
  const navLinks = $$(".nav__links a");
  const sectionObs = new IntersectionObserver(
    (entries) => entries.forEach((e) => {
      if (!e.isIntersecting) return;
      navLinks.forEach((a) => a.classList.toggle("is-active", a.getAttribute("href") === `#${e.target.id}`));
    }),
    { rootMargin: "-45% 0px -50% 0px" }
  );
  ["carte", "univers", "galerie", "contact"].forEach((id) => { const s = document.getElementById(id); s && sectionObs.observe(s); });

  /* ---------- Menu mobile ---------- */
  const burger = $(".burger");
  const mmenu = $("#mobile-menu");
  const setMenu = (open) => {
    document.body.classList.toggle("menu-open", open);
    burger.setAttribute("aria-expanded", String(open));
    burger.setAttribute("aria-label", open ? "Fermer le menu" : "Ouvrir le menu");
    mmenu.setAttribute("aria-hidden", String(!open));
    if (open) nav.classList.remove("is-hidden");
  };
  burger.addEventListener("click", () => setMenu(!document.body.classList.contains("menu-open")));
  $$("a", mmenu).forEach((a) => a.addEventListener("click", () => setMenu(false)));
  addEventListener("keydown", (e) => { if (e.key === "Escape" && document.body.classList.contains("menu-open")) setMenu(false); });

  /* ---------- Carte interactive ---------- */
  const grid = $("[data-menu-grid]");
  const filters = $("[data-filters]");
  const menu = window.MIAMS_MENU;
  const notes = window.MIAMS_CATEGORY_NOTES;
  const cats = window.MIAMS_CATEGORIES;
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const count = (id) => (id === "all" ? menu.length : menu.filter((d) => d.category === id).length);
  filters.innerHTML = cats
    .map((c, i) => {
      const n = count(c.id);
      return `<button class="filter" role="tab" id="tab-${c.id}" aria-controls="carte-grid" aria-selected="${i === 0}" tabindex="${i === 0 ? 0 : -1}" data-cat="${c.id}">${c.label}${n ? `<sup>${n}</sup>` : ""}</button>`;
    })
    .join("");
  grid.id = "carte-grid";
  grid.setAttribute("role", "tabpanel");

  const dishCard = (d, i) => `
    <article class="dish" style="--i:${i}">
      <div class="dish__media${d.image ? "" : " dish__media--type"}">
        ${d.image
          ? `<img src="${esc(d.image)}" alt="${esc(d.alt)}" loading="lazy" decoding="async" width="360" height="640" />`
          : `<div class="dish__type" aria-hidden="true">
               <svg viewBox="0 0 32 28"><path d="M8 20h16v4a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2v-4Zm-1.5-2.2A6.5 6.5 0 0 1 9 5.3a7.5 7.5 0 0 1 14 0 6.5 6.5 0 0 1 2.5 12.5H6.5Z" fill="currentColor"/></svg>
               <span>${esc(d.name)}</span>
               <small>Photo à venir</small>
             </div>`}
        ${d.tag ? `<span class="dish__tag">${esc(d.tag)}</span>` : ""}
      </div>
      <div class="dish__body">
        <div class="dish__top">
          <h3 class="dish__name">${esc(d.name)}</h3>
          ${d.price ? `<span class="dish__price">${esc(d.price)}</span>` : `<span class="dish__price dish__price--na">Prix sur place</span>`}
        </div>
        <p class="dish__desc">${esc(d.description)}</p>
        <div class="dish__foot">
          <span>${esc(cats.find((c) => c.id === d.category)?.label || "")}</span>
          <a href="${esc(d.source)}" target="_blank" rel="noopener">Voir sur Instagram ↗</a>
        </div>
      </div>
    </article>`;

  const askCard = (cat) => `
    <div class="ask">
      <div>
        <h3>${esc(cat.label)} — <em>à découvrir sur place.</em></h3>
        <p>${esc(notes[cat.id] || "")} Nous préférons ne publier que des informations confirmées&nbsp;: appelez-nous pour connaître la sélection et les prix du jour.</p>
      </div>
      <div class="ask__btns">
        <a class="btn btn--brass btn--sm" href="tel:${R.phoneIntl}">Appeler le ${R.phoneDisplay}</a>
        <a class="btn btn--ghost btn--sm" href="https://wa.me/${R.whatsapp}?text=${encodeURIComponent(`Bonjour Miam'S, pourriez-vous m'indiquer votre carte ${cat.label.toLowerCase()} et les prix ? Merci !`)}" target="_blank" rel="noopener">WhatsApp</a>
      </div>
    </div>`;

  let current = "all";
  const render = (catId) => {
    const items = catId === "all" ? menu : menu.filter((d) => d.category === catId);
    const cat = cats.find((c) => c.id === catId);
    const html = items.length ? items.map(dishCard).join("") : askCard(cat);
    const swap = () => { grid.innerHTML = html; grid.style.opacity = ""; };
    if (reduceMotion || !grid.children.length) return swap();
    grid.style.transition = "opacity .22s ease";
    grid.style.opacity = "0";
    setTimeout(swap, 220);
  };
  const select = (btn, focus = false) => {
    if (!btn || btn.dataset.cat === current) return;
    current = btn.dataset.cat;
    $$(".filter", filters).forEach((b) => { const on = b === btn; b.setAttribute("aria-selected", on); b.tabIndex = on ? 0 : -1; });
    btn.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "nearest", inline: "center" });
    if (focus) btn.focus();
    render(current);
  };
  filters.addEventListener("click", (e) => select(e.target.closest(".filter")));
  filters.addEventListener("keydown", (e) => {
    const btns = $$(".filter", filters);
    const i = btns.indexOf(document.activeElement);
    if (i < 0) return;
    if (e.key === "ArrowRight") { e.preventDefault(); select(btns[(i + 1) % btns.length], true); }
    if (e.key === "ArrowLeft") { e.preventDefault(); select(btns[(i - 1 + btns.length) % btns.length], true); }
  });
  render("all");

  /* ---------- Apparitions au défilement ---------- */
  const revealObs = new IntersectionObserver(
    (entries) => entries.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add("is-in"); revealObs.unobserve(e.target); }
    }),
    { threshold: 0.12, rootMargin: "0px 0px -6% 0px" }
  );
  $$(".reveal").forEach((el, i) => {
    // léger décalage pour les éléments d'une même grille
    if (el.parentElement?.matches(".bento, .pillars")) el.style.transitionDelay = `${(i % 4) * 80}ms`;
    revealObs.observe(el);
  });

  /* ---------- Parallaxe douce ---------- */
  const para = $$(".parallax");
  if (para.length && !reduceMotion && matchMedia("(min-width: 921px)").matches) {
    let ticking = false;
    const run = () => {
      para.forEach((el) => {
        const r = el.getBoundingClientRect();
        const offset = (r.top + r.height / 2 - innerHeight / 2) * parseFloat(el.dataset.speed || 0);
        el.style.translate = `0 ${offset.toFixed(1)}px`;
      });
      ticking = false;
    };
    addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(run); } }, { passive: true });
    run();
  }

  /* ---------- Galerie / visionneuse ---------- */
  const items = $$(".bento__item");
  const lb = $(".lightbox");
  const lbImg = $("img", lb);
  const lbCap = $("figcaption", lb);
  let idx = 0, lastFocus = null;
  const show = (i) => {
    idx = (i + items.length) % items.length;
    const img = $("img", items[idx]);
    lbImg.src = img.currentSrc || img.src;
    lbImg.alt = img.alt;
    lbCap.textContent = $("span", items[idx]).textContent;
    lbImg.style.animation = "none"; void lbImg.offsetWidth; lbImg.style.animation = "";
  };
  const openLb = (i) => { lastFocus = document.activeElement; show(i); lb.hidden = false; document.body.style.overflow = "hidden"; $(".lightbox__close", lb).focus(); };
  const closeLb = () => { lb.hidden = true; document.body.style.overflow = ""; lastFocus?.focus(); };
  items.forEach((b, i) => b.addEventListener("click", () => openLb(i)));
  $(".lightbox__close", lb).addEventListener("click", closeLb);
  $(".lightbox__nav--prev", lb).addEventListener("click", () => show(idx - 1));
  $(".lightbox__nav--next", lb).addEventListener("click", () => show(idx + 1));
  lb.addEventListener("click", (e) => { if (e.target === lb) closeLb(); });
  addEventListener("keydown", (e) => {
    if (lb.hidden) return;
    if (e.key === "Escape") closeLb();
    if (e.key === "ArrowRight") show(idx + 1);
    if (e.key === "ArrowLeft") show(idx - 1);
    if (e.key === "Tab") { // piège de focus simple
      const f = $$("button", lb); const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  // balayage tactile
  let sx = 0;
  lb.addEventListener("touchstart", (e) => { sx = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener("touchend", (e) => { const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) show(idx + (dx < 0 ? 1 : -1)); });

  /* ---------- Réservation ---------- */
  const form = $("[data-booking]");
  const fDate = $("#f-date", form);
  const fTime = $("#f-time", form);
  const fGuests = $("#f-guests", form);

  const pad = (n) => String(n).padStart(2, "0");
  const tunisDateISO = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Tunis" }).format(new Date());
  fDate.min = tunisDateISO();
  fDate.value = tunisDateISO();

  // Créneaux de 11:00 à 22:30 (dernière arrivée avant la fermeture de 23h)
  const slots = [];
  for (let m = toMin(R.hours.open); m <= toMin(R.hours.close) - 30; m += 30) slots.push(`${pad(Math.floor(m / 60))}:${pad(m % 60)}`);
  const fillSlots = () => {
    const isToday = fDate.value === tunisDateISO();
    const nowMin = tunisNow().minutes;
    const prev = fTime.value;
    fTime.innerHTML = `<option value="">Choisir</option>` + slots
      .map((s) => `<option value="${s}" ${isToday && toMin(s) <= nowMin + 30 ? "disabled" : ""}>${s.replace(":", "h")}</option>`)
      .join("");
    if (prev && !fTime.querySelector(`option[value="${prev}"]:not([disabled])`)) fTime.value = "";
    else fTime.value = prev;
  };
  fillSlots();
  fDate.addEventListener("change", fillSlots);

  $$("[data-step]", form).forEach((b) => b.addEventListener("click", () => {
    const v = Math.min(50, Math.max(1, (parseInt(fGuests.value, 10) || 1) + Number(b.dataset.step)));
    fGuests.value = v;
    fGuests.dispatchEvent(new Event("input"));
  }));

  const setErr = (input, msg) => {
    const field = input.closest(".field");
    field.classList.toggle("is-invalid", !!msg);
    $(".field__err", field).textContent = msg || "";
    input.setAttribute("aria-invalid", msg ? "true" : "false");
  };
  const validate = () => {
    const d = Object.fromEntries(new FormData(form));
    const errs = [];
    const check = (name, msg) => { const el = form.elements[name]; setErr(el, msg); if (msg) errs.push(el); };
    check("name", d.name.trim().length >= 2 ? "" : "Indiquez votre nom et prénom.");
    const digits = d.phone.replace(/\D/g, "");
    check("phone", digits.length >= 8 ? "" : "Numéro de téléphone invalide.");
    check("date", d.date && d.date >= fDate.min ? "" : "Choisissez une date à venir.");
    check("time", d.time ? "" : "Choisissez une heure.");
    const g = parseInt(d.guests, 10);
    check("guests", g >= 1 && g <= 50 ? "" : "Entre 1 et 50 personnes.");
    if (errs.length) errs[0].focus();
    return errs.length ? null : d;
  };
  $$("input, select", form).forEach((el) => el.addEventListener("input", () => el.closest(".field")?.classList.contains("is-invalid") && setErr(el, "")));

  const buildMessage = (d) => {
    const date = new Date(`${d.date}T12:00:00`).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    return [
      "Bonjour Miam'S, je souhaite réserver une table :",
      `• Nom : ${d.name.trim()}`,
      `• Téléphone : ${d.phone.trim()}`,
      `• Date : ${date}`,
      `• Heure : ${d.time.replace(":", "h")}`,
      `• Personnes : ${d.guests}`,
      d.message.trim() ? `• Message : ${d.message.trim()}` : "",
      "Merci de me confirmer la disponibilité.",
    ].filter(Boolean).join("\n");
  };
  const done = $(".form__done", form);

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const d = validate();
    if (!d) return;
    window.open(`https://wa.me/${R.whatsapp}?text=${encodeURIComponent(buildMessage(d))}`, "_blank", "noopener");
    done.hidden = false;
  });
  $("[data-sms]", form).addEventListener("click", () => {
    const d = validate();
    if (!d) return;
    const sep = /iPhone|iPad|Mac/i.test(navigator.userAgent) ? "&" : "?";
    location.href = `sms:${R.phoneIntl}${sep}body=${encodeURIComponent(buildMessage(d))}`;
  });

  /* ---------- Divers ---------- */
  $$("[data-year]").forEach((el) => (el.textContent = new Date().getFullYear()));
})();
