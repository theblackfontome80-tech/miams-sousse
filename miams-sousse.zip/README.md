# Miam'S Hammam Sousse — site web

Site vitrine statique (HTML/CSS/JS, aucune dépendance, aucun build).

## Lancer en local
```
node serve.mjs
```
puis ouvrir http://localhost:5173

## Mettre en ligne
Déposer le dossier tel quel sur n'importe quel hébergeur statique
(Netlify, Vercel, GitHub Pages, Cloudflare Pages, OVH…).
Une fois le nom de domaine connu, remplacer `./` par l'URL complète dans
la balise `<link rel="canonical">` et les `og:image` de `index.html`.

## Modifier la carte
Tout se trouve dans `assets/js/data.js` :
- `MIAMS_MENU` : un objet par plat (`category`, `name`, `description`, `price`, `image`).
  Laisser `price: null` affiche « Prix sur place ».
- Une catégorie sans plat affiche automatiquement un encart « à découvrir sur place »
  avec boutons Appeler / WhatsApp.

## Sources des informations
- Google Maps : adresse (Route de la Plage, VJ74+HHG), téléphone 52 323 073,
  horaires 11:00–23:00 tous les jours, note 4,0 (1 063 avis).
- Instagram @miamssousse : photos et noms des plats (Miam'S Burger, Planche Trésor,
  Paella Façon Chef, Poisson Royal, Paleron/Ribs, plateau à 67 DT).
  Les photos de plats ribs-aubergine, ribs-puree et paella-chef sont extraites des vidéos
  officielles (reels) du compte — aucune image générée par IA.

## À confirmer avec le restaurant
- Le 52 323 073 est-il bien joignable sur WhatsApp ? (réservations + boutons WhatsApp)
- Carte complète et prix (entrées, pizzas, desserts, boissons).
- Logo vectoriel officiel et photos haute définition (les visuels actuels
  proviennent d'Instagram, 360–640 px).
