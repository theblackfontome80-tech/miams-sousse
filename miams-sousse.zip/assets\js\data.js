/* =========================================================================
   MIAM'S — Données du restaurant
   -------------------------------------------------------------------------
   Toutes les informations ci-dessous proviennent de sources officielles :
   - Fiche Google Maps « Restaurant Miam's Hammam Sousse »
   - Compte Instagram @miamssousse (légendes des publications)
   Pour ajouter un plat : copiez un objet dans MENU, renseignez la catégorie,
   et laissez `price: null` tant que le tarif n'est pas confirmé.
   ========================================================================= */

window.MIAMS = {
  name: "Miam'S",
  fullName: "Restaurant Miam's Hammam Sousse",
  phoneDisplay: "52 323 073",
  phoneIntl: "+21652323073",
  whatsapp: "21652323073",
  instagram: "https://www.instagram.com/miamssousse/",
  mapsLink: "https://maps.app.goo.gl/R4qY8ikk92cMAxcV7",
  address: "Route de la Plage, Hammam Sousse",
  plusCode: "VJ74+HHG",
  geo: { lat: 35.8639355, lng: 10.6064403 },
  // Horaires Google Maps : 11:00–23:00 tous les jours
  hours: { open: "11:00", close: "23:00" },
  rating: { value: "4,0", count: "1 063" },
  followers: "33,7 k",
};

window.MIAMS_CATEGORIES = [
  { id: "all", label: "Tout" },
  { id: "entrees", label: "Entrées" },
  { id: "burgers", label: "Burgers" },
  { id: "pizzas", label: "Pizzas" },
  { id: "pates", label: "Pâtes" },
  { id: "grillades", label: "Grillades" },
  { id: "plats", label: "Plats" },
  { id: "desserts", label: "Desserts" },
  { id: "boissons", label: "Boissons" },
];

/* Plats vérifiés via les publications officielles @miamssousse.
   `source` = lien de la publication Instagram d'origine. */
window.MIAMS_MENU = [
  {
    id: "miams-burger",
    category: "burgers",
    name: "Miam'S Burger",
    tag: "Signature",
    description:
      "Le burger signature de la maison : « pas un burger ordinaire, mais un autre niveau de plaisir », promet l'équipe.",
    price: null,
    image: "assets/img/burger-maison.webp", // photo réelle (story « À la une » @miamssousse)
    alt: "Burger maison Miam'S : pain brioché, steak, fromage fondant, tomates confites, champignons et sauce verte",
    source: "https://www.instagram.com/stories/highlights/18049388908120440/",
  },
  {
    id: "pizza-feu-de-bois",
    category: "pizzas",
    name: "Pizza au feu de bois",
    tag: "Four à bois",
    description:
      "Pâte étalée à la main, sauce tomate et fromage, cuite dans notre four à bois — l'une des plus citées par nos clients.",
    price: null,
    image: "assets/img/pizza-feu-de-bois.webp",
    alt: "Pizza sortant du four à bois de Miam'S, braises visibles au fond",
    source: "https://www.instagram.com/miamssousse/reel/DfFDv5rgTyx/",
  },
  {
    id: "planche-tresor",
    category: "plats",
    name: "Planche Trésor",
    tag: "À partager",
    description:
      "La planche devenue un rendez-vous chez Miam'S : celle que l'on partage en famille et entre proches.",
    price: null,
    image: null, // aucune photo réelle publiée pour l'instant
    alt: "",
    source: "https://www.instagram.com/miamssousse/p/Df11dScFZ7W/",
  },
  {
    id: "plateau-67",
    category: "plats",
    name: "Le Grand Plateau",
    tag: "Généreux",
    description:
      "Un plateau copieux pensé pour une personne… qui peut en rassasier deux.",
    price: "67 DT",
    image: "assets/img/plateau-67.webp",
    alt: "Plateau généreux sortant de la cuisine ouverte de Miam'S",
    source: "https://www.instagram.com/miamssousse/reel/DfHp-ikDAlA/",
  },
  {
    id: "poisson-royal",
    category: "plats",
    name: "Poisson Royal",
    tag: "Mer",
    description:
      "Poisson entier farci au riz et aux calamars, préparé à la main par le chef.",
    price: null,
    image: "assets/img/poisson-royal.webp",
    alt: "Le chef de Miam'S préparant le Poisson Royal en cuisine",
    source: "https://www.instagram.com/miamssousse/reel/DfuMS-XoIPS/",
  },
  {
    id: "paella-chef",
    category: "plats",
    name: "Paella Façon Chef",
    tag: "Création du chef",
    description:
      "Riz safrané, crevettes, calamars, moules, coquilles Saint-Jacques et poulet, flambés et dressés à la manière du chef.",
    price: null,
    image: "assets/img/paella-chef.webp",
    alt: "Paella Façon Chef aux fruits de mer, vue de dessus",
    source: "https://www.instagram.com/miamssousse/reel/DfXJhCtDfoq/",
  },
  {
    id: "paleron-ribs",
    category: "grillades",
    name: "Paleron & Ribs",
    tag: "Au feu",
    description:
      "Ribs fondants dressés sur une purée onctueuse, avec grenade, vermicelles croustillants aux amandes et aubergine gratinée.",
    price: null,
    image: "assets/img/ribs-puree.webp",
    alt: "Ribs sur purée, grenade et vermicelles aux amandes",
    source: "https://www.instagram.com/miamssousse/reel/DfcRJFOGdpc/",
  },
];

/* Texte affiché pour une catégorie dont la carte n'est pas encore publiée
   en ligne : on n'invente rien, on invite à demander la sélection du jour. */
window.MIAMS_CATEGORY_NOTES = {
  entrees: "Nos entrées du moment vous sont présentées à table.",
  pates: "Nos pâtes du moment vous sont présentées à table.",
  pizzas:"La pizza fait partie des plats les plus cités par nos clients dans leurs avis Google.",
  desserts: "Gardez une place : la sélection de desserts vous est proposée sur place.",
  boissons: "La carte des boissons vous est présentée sur place.",
};
